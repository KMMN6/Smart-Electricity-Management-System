from django.db import models
from django.conf import settings
from django.contrib.auth.models import AbstractUser
from firebase_admin import db
from .utils import send_sms_alert  # Twilio SMS function


class CustomUser(AbstractUser):
    """
    Custom user model that uses phone number for authentication.
    """
    username = None  # Remove default username field
    phone_number = models.CharField(max_length=15, unique=True)  # Use phone number for login
    USERNAME_FIELD = 'phone_number'
    REQUIRED_FIELDS = ['first_name', 'last_name', 'password']

    def __str__(self):
        return self.phone_number
    

import random
import time
from django.core.cache import cache  # Using cache to store OTP temporarily

class Meter(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    meter_id = models.CharField(max_length=50, unique=True)
    meter_name = models.CharField(max_length=100)
    previous_bill = models.FloatField(default=0.0)

    def get_current_bill(self):
        meter_ref = db.reference(f"meters/{self.meter_id}")
        meter_data = meter_ref.get()
        return meter_data.get("unit", 0) * 8 if meter_data else 0

    # def check_bill_threshold(self):
    #     current_bill = self.get_current_bill()
    #     if self.previous_bill > 0 and current_bill >= 0.9 * self.previous_bill:
    #         message_body = (
    #             f"⚠️ Energy Alert for {self.meter_name}! "
    #             f"Your bill is ₹{current_bill}, nearing last month's ₹{self.previous_bill}. "
    #             "Please monitor usage."
    #         )
    #         send_sms_alert(self.user.phone_number, message_body)

    def pay_bill(self):
        current_bill = self.get_current_bill()
        self.previous_bill = current_bill
        meter_ref = db.reference(f"meters/{self.meter_id}")
        meter_ref.update({"unit": 0})
        self.save()

    def generate_otp(self):
        otp = random.randint(100000, 999999)  # Generate 6-digit OTP
        sanitized_phone = self.user.phone_number.replace(' ', '').replace('+', '')  # Ensure uniform format
        cache_key = f"otp_{sanitized_phone}"
    
        cache.set(cache_key, otp, timeout=300)  # Store OTP in cache for 5 mins
        print(f"Generated OTP: {otp} for {cache_key}")  # Debug print

        return otp


    

    def verify_otp(self, otp):
        sanitized_phone = self.user.phone_number.replace(' ', '')  # Replace + with _
        stored_otp = cache.get(f"otp_{sanitized_phone}")
        return stored_otp == otp


class HouseBill(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    total_bill = models.FloatField(default=0.0)
    previous_bill = models.FloatField(default=0.0)
    alert_sent = models.BooleanField(default=False)  # New field to track SMS alerts

    def check_bill_threshold(self):
        """
        Check if the total bill exceeds 90% of the previous bill and send a single SMS alert per billing cycle.
        """
        if self.previous_bill > 0 and self.total_bill >= 0.9 * self.previous_bill and not self.alert_sent:
            message_body = (
                f"⚠️ Energy Alert! Your total bill is ₹{self.total_bill}, "
                f"which is nearing last month's ₹{self.previous_bill}. "
                "Please monitor usage to avoid high costs."
            )
            send_sms_alert(self.user.phone_number, message_body)
            self.alert_sent = True  # Mark alert as sent
            self.save()

    def reset_alert(self):
        """Resets the alert flag when a new billing cycle starts."""
        self.alert_sent = False
        self.save()

    def __str__(self):
        return f"Total Bill for {self.user.phone_number}"
