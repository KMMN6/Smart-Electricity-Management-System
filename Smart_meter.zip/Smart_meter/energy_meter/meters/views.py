# Standard library imports
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required

# Third-party imports
from firebase_admin import db

# Local application imports
from .forms import SignupForm, LoginForm, AddMeterForm
from .models import Meter,HouseBill

# Views
def signup_view(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            user = form.save()
            return redirect('login')  # Redirect to login page after signup
    else:
        form = SignupForm()
    return render(request, 'signup.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            phone_number = form.cleaned_data['phone_number']
            password = form.cleaned_data['password']
            user = authenticate(phone_number=phone_number, password=password)
            if user:
                login(request, user)
                return redirect('dashboard')  # Redirect to dashboard after login
    else:
        form = LoginForm()
    return render(request, 'login.html', {'form': form})

@login_required
def dashboard_view(request):
    meters = Meter.objects.filter(user=request.user)
    meter_data_list = []
    total_bill = 0  # Initialize total bill to 0

    # Retrieve or create the HouseBill for the user
    house_bill, created = HouseBill.objects.get_or_create(user=request.user)

    for meter in meters:
        meter_ref = db.reference(f"meters/{meter.meter_id}")
        meter_data = meter_ref.get() or {}

        if meter_data:
            unit = meter_data.get("unit", 0)  # Energy in kWh
            bill = unit * 8  # ₹8 per unit

            meter_info = {
                "meter_id": meter.meter_id,
                "meter_name": meter.meter_name,
                "voltage": meter_data.get("voltage", "N/A"),
                "current": meter_data.get("current", "N/A"),
                "power": meter_data.get("power", "N/A"),
                "unit": unit,
                "bill": bill
            }
            meter_data_list.append(meter_info)

            total_bill += bill  # Add the current meter's bill to the total bill

    # Update the HouseBill with the newly calculated total_bill
    house_bill.total_bill = total_bill
    house_bill.save()

    # ✅ Check total bill threshold AFTER updating it
    house_bill.check_bill_threshold()

    return render(request, 'dashboard.html', {
        'meters': meter_data_list,
        'total_bill': total_bill,  # Dynamic total bill
        'previous_bill': house_bill.previous_bill
    })


@login_required
def pay_bill(request, meter_id):
    """Handles the bill payment and resets the current bill to zero. Updates the total bill."""
    meter = get_object_or_404(Meter, meter_id=meter_id, user=request.user)
    meter.pay_bill()  # Calls the function in models.py to reset the bill

    # Calculate the new total bill after payment
    meters = Meter.objects.filter(user=request.user)
    total_bill = sum([m.get_current_bill() for m in meters])

    return redirect('dashboard')  # Redirects back to dashboard

@login_required
def add_meter_view(request):
    if request.method == "POST":
        form = AddMeterForm(request.POST)
        if form.is_valid():
            meter = form.save(commit=False)
            meter.user = request.user  # Associate meter with logged-in user
            meter.save()
            return redirect('dashboard')  # Redirect back to dashboard
    else:
        form = AddMeterForm()
    
    return render(request, 'add_meter.html', {'form': form})

@login_required
def get_meter_data(request, meter_id):
    meter_ref = db.reference(f"meters/{meter_id}")
    meter_data = meter_ref.get()

    if meter_data:
        unit = meter_data.get("unit", 0)  # kWh consumption
        bill = unit * 8  # ₹8 per unit
        
        return JsonResponse({
            "voltage": meter_data.get("voltage", "N/A"),
            "current": meter_data.get("current", "N/A"),
            "power": meter_data.get("power", "N/A"),
            "unit": unit,
            "bill": bill
        })
    else:
        return JsonResponse({"error": "Meter not found"}, status=404)

def logout_view(request):
    logout(request)
    return redirect('landing')  # Redirect to login page after logout

from .utils import send_sms_alert  # Import for sending SMS

@login_required
def pay_all_bills(request):
    """Handles the payment for all meters and generates OTP."""
    meters = Meter.objects.filter(user=request.user)
    total_bill = sum([meter.get_current_bill() for meter in meters])  # Sum of all meters' bills

    # Create or update the HouseBill for the user
    house_bill, created = HouseBill.objects.get_or_create(user=request.user)
    house_bill.total_bill = total_bill  # Update the house total bill
    house_bill.save()

    # Generate OTP for payment (only once, and store in cache)
    meter = meters.first()  # Assuming the first meter for OTP generation
    otp = meter.generate_otp()

    # Send OTP via SMS
    send_sms_alert(request.user.phone_number, f"Your OTP for paying the bill: {otp}")

    # Show OTP input form in the next view
    return render(request, 'verify_otp.html', {'total_bill': total_bill})

from django.core.cache import cache
from django.contrib import messages
from django.shortcuts import redirect
from django.contrib import messages

@login_required
def verify_otp(request):
    """Verify the OTP entered by the user and complete the payment."""
    if request.method == 'POST':
        otp_entered = request.POST.get('otp')

        meter = Meter.objects.filter(user=request.user).first()  
        if meter:
            sanitized_phone = meter.user.phone_number.replace(' ', '').replace('+', '')
            cache_key = f"otp_{sanitized_phone}"
            stored_otp = cache.get(cache_key)

            print(f"Entered OTP: {otp_entered}, Stored OTP: {stored_otp}, Cache Key: {cache_key}")  

            if stored_otp and str(stored_otp) == otp_entered:
                house_bill = HouseBill.objects.get(user=request.user)
                total_paid = house_bill.total_bill  
                house_bill.previous_bill = total_paid  
                house_bill.total_bill = 0  
                house_bill.reset_alert()  # Reset alert flag after payment
                house_bill.save()

                for meter in Meter.objects.filter(user=request.user):
                    meter.pay_bill()  

                cache.delete(cache_key)

                message_body = (
                    f"✅ Payment Successful! You have paid ₹{total_paid} for all meters. "
                    "Your energy bills have been reset."
                )
                send_sms_alert(request.user.phone_number, message_body)

                messages.success(request, f"Payment successful! ₹{total_paid} has been paid for all meters.")
                return redirect('dashboard')  
            else:
                messages.error(request, "Invalid OTP. Please try again.")
                return redirect('pay_all_bills')  

    return render(request, 'verify_otp.html')

# meters/views.py
from django.shortcuts import render

def landing_view(request):
    return render(request, 'landing.html')

