from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser

class SignupForm(UserCreationForm):
    phone_number = forms.CharField(max_length=15)

    class Meta:
        model = CustomUser
        fields = ['first_name', 'last_name', 'phone_number', 'password1', 'password2']
from django import forms
from django.contrib.auth import authenticate

class LoginForm(forms.Form):
    phone_number = forms.CharField(max_length=15, label="Phone Number")
    password = forms.CharField(widget=forms.PasswordInput, label="Password")

    def clean(self):
        phone_number = self.cleaned_data.get('phone_number')
        password = self.cleaned_data.get('password')
        user = authenticate(phone_number=phone_number, password=password)

        if not user:
            raise forms.ValidationError("Invalid phone number or password")
        return self.cleaned_data
from django import forms
from .models import Meter

class AddMeterForm(forms.ModelForm):
    class Meta:
        model = Meter
        fields = ['meter_id', 'meter_name']

