from django.urls import path
from . import views
from .views import signup_view,login_view,dashboard_view,add_meter_view,get_meter_data,logout_view,pay_bill

urlpatterns = [
    path('signup/', signup_view, name='signup'),
    path('login/', login_view, name='login'), 
    path('dashboard/', dashboard_view, name='dashboard'),
    path('add-meter/', add_meter_view, name='add_meter'),
    path('get_meter_data/<str:meter_id>/', get_meter_data, name='get_meter_data'),
    path('pay_bill/<str:meter_id>/', pay_bill, name='pay_bill'),
    path('logout/', logout_view, name='logout'),
    path('pay_all_bills/', views.pay_all_bills, name='pay_all_bills'),
    path('verify_otp/', views.verify_otp, name='verify_otp'),

]
